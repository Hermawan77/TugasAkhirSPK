<section class="content">
	<div class="box box-primary">
		<div class="box-header with-border">
			<h3 class="box-title"><b>Tentang</b></h3>
			<p>SPK AHP TOPSIS dan VIKOR adalah Sistem Pendukung Keputusan Penentuan Kelompok Keilmuan Mahasiswa 
				Teknik Informatika ITERA dengan menggunakan metode AHP, TOPSIS dan VIKOR</p>
			<p>Versi 1.0
				<br>Dibuat oleh :
				<br>Nama		: Dicky Hermawan
				<br>NIM			: 14116005
				<br>Prodi		: Teknik Informatika
			</br>
			</br>
			</br>
			</br>
			</p>
		</div>
		<!-- /.box-body -->
	</div>
</section>