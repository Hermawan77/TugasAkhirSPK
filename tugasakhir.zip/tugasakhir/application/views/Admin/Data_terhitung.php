<!-- Main content -->
<section class="content">
    <div class="box box-primary">
        <div class="col" style="padding:12px">
            <a href="<?= base_url() ?>admin_controller">
                <i class="fa fa-arrow-circle-left fa-lg"></i>
            </a>
        </div>  
    </div>
</section>